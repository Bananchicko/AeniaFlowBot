"""Shared bot infrastructure."""
